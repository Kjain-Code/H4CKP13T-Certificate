import './App.css';
import CertificateVerification from './components/validation';

function App() {
  return (
    <>
      <CertificateVerification/>
    </>
  );
}

export default App;
